from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi
from fastapi.staticfiles import StaticFiles  # <-- Añadido para servir frontend

from app.routes import auth, plan, stripe_routes, stripe_webhook  # Añadido stripe_webhook

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ───── MONTAJE DE FRONTEND ─────
app.mount("/frontend", StaticFiles(directory="app/frontend", html=True), name="frontend")

# ───── RUTAS API ─────
app.include_router(auth.router)
app.include_router(plan.router)
app.include_router(stripe_routes.router)
app.include_router(stripe_webhook.router)  # Añadido router webhook

@app.get("/")
def root():
    return {"message": "GYM AI API"}

def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title="Gym AI API",
        version="1.0",
        description="API de entrenamiento y dieta con IA",
        routes=app.routes,
    )
    openapi_schema["components"]["securitySchemes"] = {
        "BearerAuth": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "JWT",
        }
    }
    for path in openapi_schema["paths"].values():
        for method in path.values():
            method["security"] = [{"BearerAuth": []}]
    app.openapi_schema = openapi_schema
    return app.openapi_schema

app.openapi = custom_openapi
