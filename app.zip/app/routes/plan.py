from fastapi import APIRouter, Depends, HTTPException, status, Body
from sqlalchemy.orm import Session
from app.database import get_db
from app.auth_utils import get_current_user
from app.schemas import PlanRequest, PlanResponse
from app.models import Usuario, Plan
from datetime import datetime
from fastapi.security import HTTPBearer
from typing import List
from app.utils.gpt import generar_plan_personalizado
import json

router = APIRouter()
security = HTTPBearer()

@router.post("/generar-rutina", response_model=PlanResponse, dependencies=[Depends(security)])
def generar_rutina(
    datos: PlanRequest = Body(...),
    db: Session = Depends(get_db),
    usuario: Usuario = Depends(get_current_user)
):
    try:
        plan_generado = generar_plan_personalizado(datos)

        rutina_str = json.dumps(plan_generado["rutina"]) if isinstance(plan_generado["rutina"], (dict, list)) else plan_generado["rutina"]
        dieta_str = json.dumps(plan_generado["dieta"]) if isinstance(plan_generado["dieta"], (dict, list)) else plan_generado["dieta"]
        motivacion_str = json.dumps(plan_generado["motivacion"]) if isinstance(plan_generado["motivacion"], (dict, list)) else plan_generado["motivacion"]

        nuevo_plan = Plan(
            user_id=usuario.id,
            altura=datos.altura,
            peso=datos.peso,
            edad=datos.edad,
            sexo=datos.sexo,
            experiencia=datos.experiencia,
            objetivo=datos.objetivo,
            materiales=datos.materiales,
            tipo_cuerpo=datos.tipo_cuerpo,
            idioma=datos.idioma,
            puntos_fuertes=datos.puntos_fuertes,
            puntos_debiles=datos.puntos_debiles,
            entrenar_fuerte=datos.entrenar_fuerte,
            lesiones=datos.lesiones,
            alergias=datos.alergias,
            restricciones_dieta=datos.restricciones_dieta,
            rutina=rutina_str,
            dieta=dieta_str,
            motivacion=motivacion_str,
            fecha_creacion=datetime.utcnow()
        )

        db.add(nuevo_plan)
        db.commit()
        db.refresh(nuevo_plan)

        return PlanResponse(
            rutina=plan_generado["rutina"],
            dieta=plan_generado["dieta"],
            motivacion=plan_generado["motivacion"]
        )

    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error al generar plan: {str(e)}")

@router.get("/planes", response_model=List[PlanResponse], dependencies=[Depends(security)])
def obtener_planes(
    db: Session = Depends(get_db),
    usuario: Usuario = Depends(get_current_user)
):
    planes = db.query(Plan).filter(Plan.user_id == usuario.id).order_by(Plan.fecha_creacion.desc()).all()
    return [
        PlanResponse(
            rutina=json.loads(plan.rutina),
            dieta=json.loads(plan.dieta),
            motivacion=plan.motivacion
        )
        for plan in planes
    ]
