from fastapi import APIRouter, Request, HTTPException
import stripe
import os

router = APIRouter()

stripe.api_key = os.getenv("STRIPE_SECRET_KEY")
endpoint_secret = os.getenv("STRIPE_WEBHOOK_SECRET")  # La configuraremos luego en .env

@router.post("/webhook")
async def stripe_webhook(request: Request):
    payload = await request.body()
    sig_header = request.headers.get("stripe-signature")

    if endpoint_secret is None:
        raise HTTPException(status_code=500, detail="Stripe webhook secret no configurado")

    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, endpoint_secret
        )
    except ValueError:
        raise HTTPException(status_code=400, detail="Payload inválido")
    except stripe.error.SignatureVerificationError:
        raise HTTPException(status_code=400, detail="Firma webhook inválida")

    event_type = event["type"]
    data = event["data"]["object"]

    # Aquí solo imprimimos, luego puedes añadir lógica para guardar en base de datos
    if event_type == "customer.subscription.created":
        print(f"Suscripción creada: {data['id']}")

    elif event_type == "customer.subscription.updated":
        print(f"Suscripción actualizada: {data['id']}")

    elif event_type == "customer.subscription.deleted":
        print(f"Suscripción cancelada: {data['id']}")

    elif event_type == "invoice.payment_succeeded":
        print(f"Pago realizado para factura: {data['id']}")

    elif event_type == "invoice.payment_failed":
        print(f"Pago fallido para factura: {data['id']}")

    return {"status": "success"}
