from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel
import stripe
import os

router = APIRouter()

stripe.api_key = os.getenv("STRIPE_SECRET_KEY")

class CheckoutSessionRequest(BaseModel):
    price_id: str  # ID del precio seleccionado

@router.post("/create-checkout-session")
async def create_checkout_session(data: CheckoutSessionRequest, request: Request):
    try:
        # Cambia esto a tu dominio frontend real cuando estés en producción
        domain_url = "http://localhost:3000"

        # ID del plan mensual que tiene prueba gratuita de 7 días
        precio_mensual_con_trial = "price_1Rnd0Fjp4vhqjXAutnWBMvS"

        trial_days = 7 if data.price_id == precio_mensual_con_trial else 0

        session = stripe.checkout.Session.create(
            success_url=domain_url + "/success?session_id={CHECKOUT_SESSION_ID}",
            cancel_url=domain_url + "/cancel",
            payment_method_types=["card"],
            mode="subscription",
            line_items=[{"price": data.price_id, "quantity": 1}],
            subscription_data={"trial_period_days": trial_days} if trial_days > 0 else {},
            allow_promotion_codes=True,
        )
        return {"url": session.url}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
