const SUPABASE_URL = "https://zqjrwsaouawobzvogytp.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpxanJ3c2FvdWF3b2J6dm9neXRwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMxMzc2MzUsImV4cCI6MjA2ODcxMzYzNX0.0bDlnzlemwyyFK1Qvtb_RGwecycMkFI1avJPsDAV9y8";

import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm";
const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

const email     = document.getElementById("email");
const password  = document.getElementById("password");
const loginBtn  = document.getElementById("login");
const regBtn    = document.getElementById("register");
const msgBox    = document.getElementById("msg");

function show(msg, ok = false) {
  msgBox.style.color = ok ? "green" : "red";
  msgBox.textContent = msg;
}

loginBtn.addEventListener("click", async () => {
  if (!email.value.trim() || !password.value.trim()) {
    return show("Por favor, introduce email y contraseña.");
  }

  const { error, data } = await supabase.auth.signInWithPassword({
    email: email.value.trim(),
    password: password.value.trim()
  });

  if (error) return show(error.message);
  
  // Guarda la sesión en localStorage para uso futuro
  localStorage.setItem('supabaseSession', JSON.stringify(data.session));
  
  show("✔️ ¡Bienvenido!", true);
  window.location.href = "./tarifas.html";
});

regBtn.addEventListener("click", async () => {
  if (!email.value.trim() || !password.value.trim()) {
    return show("Por favor, introduce email y contraseña.");
  }

  const { error } = await supabase.auth.signUp({
    email: email.value.trim(),
    password: password.value.trim()
  });

  if (error) {
    show(error.message);
  } else {
    show("✔️ Registro enviado. Revisa tu correo para confirmar.", true);
  }
});
