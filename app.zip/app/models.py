from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database import Base

class Usuario(Base):
    __tablename__ = "usuarios"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True)
    hashed_password = Column(String)
    
    planes = relationship("Plan", back_populates="usuario")

class Plan(Base):
    __tablename__ = "planes"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("usuarios.id"))

    altura = Column(Integer, nullable=False)
    peso = Column(Integer, nullable=False)
    edad = Column(Integer, nullable=False)
    sexo = Column(String, nullable=False)
    experiencia = Column(String, nullable=False)
    objetivo = Column(String, nullable=False)
    materiales = Column(String, nullable=False)
    tipo_cuerpo = Column(String, nullable=True)
    idioma = Column(String, default="es")
    puntos_fuertes = Column(String, nullable=True)
    puntos_debiles = Column(String, nullable=True)
    entrenar_fuerte = Column(String, nullable=True)
    lesiones = Column(String, nullable=True)
    alergias = Column(String, nullable=True)
    restricciones_dieta = Column(String, nullable=True)

    rutina = Column(Text, nullable=False)       # ✅ cambiado a Text
    dieta = Column(Text, nullable=False)        # ✅ cambiado a Text
    motivacion = Column(Text, nullable=False)   # ✅ por si es larga

    fecha_creacion = Column(DateTime, default=datetime.utcnow)

    usuario = relationship("Usuario", back_populates="planes")
