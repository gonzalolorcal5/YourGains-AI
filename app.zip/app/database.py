from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import StaticPool
from dotenv import load_dotenv
import os

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./gymai.db")

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# ✅ ESTA FUNCIÓN ES LA CLAVE:
def get_db():
    db: Session = SessionLocal()
    try:
        yield db
    finally:
        db.close()

from app.models import Base  # importa el Base que define tus modelos

Base.metadata.create_all(bind=engine)
 

